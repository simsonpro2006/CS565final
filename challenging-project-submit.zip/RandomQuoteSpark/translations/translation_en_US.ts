<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Ask author</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Sure, from what author?</source>
            <comment>Text</comment>
            <translation type="unfinished">Sure, from what author?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hello Justin</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello Justin</translation>
        </message>
        <message>
            <source>Okay, from what author?</source>
            <comment>Text</comment>
            <translation type="obsolete">Okay, from what author?</translation>
        </message>
        <message>
            <source>Sure, from what author?</source>
            <comment>Text</comment>
            <translation type="obsolete">Sure, from what author?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Sorry, I don't know any quotes from that person</source>
            <comment>Text</comment>
            <translation type="obsolete">Sorry, I don't know any quotes from that person</translation>
        </message>
        <message>
            <source>Sorry, I dont know any quotes from that person</source>
            <comment>Text</comment>
            <translation type="obsolete">Sorry, I dont know any quotes from that person</translation>
        </message>
        <message>
            <source>Sorry, I dont know them</source>
            <comment>Text</comment>
            <translation type="obsolete">Sorry, I dont know them</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Yeah, sure. Just give me a second.</source>
            <comment>Text</comment>
            <translation type="obsolete">Yeah, sure. Just give me a second.</translation>
        </message>
        <message>
            <source>Yeah sure just give me a second</source>
            <comment>Text</comment>
            <translation type="obsolete">Yeah sure just give me a second</translation>
        </message>
        <message>
            <source>Okay</source>
            <comment>Text</comment>
            <translation type="obsolete">Okay</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="C:/Program Files (x86)/Softbank Robotics/Choregraphe Suite 2.8/translations/behavior_1/behavior.xar" line="0"/>
            <source></source>
            <comment>Text</comment>
            <translation></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say Okay</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Okay</source>
            <comment>Text</comment>
            <translation type="unfinished">Okay</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say Quote</name>
        <message>
            <location filename="C:/Program Files (x86)/Softbank Robotics/Choregraphe Suite 2.8/translations/behavior_1/behavior.xar" line="0"/>
            <source></source>
            <comment>Text</comment>
            <translation></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say Unknown</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Sorry, I dont know them</source>
            <comment>Text</comment>
            <translation type="unfinished">Sorry, I dont know them</translation>
        </message>
    </context>
</TS>
